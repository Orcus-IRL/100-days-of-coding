# -*- coding: utf-8 -*-
"""
Created on Sun Oct 27 17:03:46 2019

@author: giles
"""

#def sum_and_mult(a,b):
#    total = a + b
#    product = a * b
#    
#    return total, product
##
#func_call = sum_and_mult(3,4)
##
#print(func_call)
#print(type(func_call))
##
#var_1, var_2 = sum_and_mult(6,7)
##
##
##
#var_3 = 5
#var_4 = 6
##
#def add1(var_3,var_4):
#    var_3 = var_3 + 1
#    var_4 = var_4 + 1
#    
#    print(f'Inside the function var_3 = {var_3} and var_4 = {var_4}')
#    return var_3,var_4
##
#add1(18,19)
#
#print(f'But outside the function var_3 = {var_3} and var_4 = {var_4}')


#def lengthen_list(n,my_list = [1,2,3]):
#    my_list.append(n)
#    
#    return my_list
#
#x = lengthen_list(4)
#
#x = lengthen_list(4)
##
#x = lengthen_list(4)
##
#def lengthen_list_2(n,my_list = None):
#    if my_list == None:
#        my_list = [1,2,3]
#        my_list.append(n)
#        return my_list
#    
#y = lengthen_list_2(4)
##
#y = lengthen_list_2(4)
##
#y = lengthen_list_2(4)

    
     




def multi_ply(a,b):
    return a * b
    
p = multi_ply(3,4)



























   