#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct 15 16:46:09 2019

@author: Giles
"""

print('One,\'two\',\"three\",four,\\five\\\n\tonce,\'I\' caught a\
 fish\n\t\t\'//alive\\\\\'')
