# 🚨 Don't change the code below 👇
age = input("What is your current age? ")
# 🚨 Don't change the code above 👆

#Write your code below this line 👇
age= int(age)
remaining = 90-age
months_left = remaining*12
days_left = remaining*365
weeks_left = remaining*52
print(f"You have {days_left} days, {weeks_left} weeks, and {months_left} months left.")



