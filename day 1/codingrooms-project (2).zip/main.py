name = input("what is your name? ")
print(len(name))