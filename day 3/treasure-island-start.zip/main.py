print('''
*******************************************************************************
          |                   |                  |                     |
 _________|________________.=""_;=.______________|_____________________|_______
|                   |  ,-"_,=""     `"=.|                  |
|___________________|__"=._o`"-._        `"=.______________|___________________
          |                `"=._o`"=._      _`"=._                     |
 _________|_____________________:=._o "=._."_.-="'"=.__________________|_______
|                   |    __.--" , ; `"=._o." ,-"""-._ ".   |
|___________________|_._"  ,. .` ` `` ,  `"-._"-._   ". '__|___________________
          |           |o`"=._` , "` `; .". ,  "-._"-._; ;              |
 _________|___________| ;`-.o`"=._; ." ` '`."\` . "-._ /_______________|_______
|                   | |o;    `"-.o`"=._``  '` " ,__.--o;   |
|___________________|_| ;     (#) `-.o `"=.`_.--"_o.-; ;___|___________________
____/______/______/___|o;._    "      `".o|o_.--"    ;o;____/______/______/____
/______/______/______/_"=._o--._        ; | ;        ; ;/______/______/______/_
____/______/______/______/__"=._o--._   ;o|o;     _._;o;____/______/______/____
/______/______/______/______/____"=._o._; | ;_.--"o.--"_/______/______/______/_
____/______/______/______/______/_____"=.o|o_.--""___/______/______/______/____
/______/______/______/______/______/______/______/______/______/______/_____ /
*******************************************************************************
''')
print("Welcome to Treasure Island.")
print("Your mission is to find the treasure.")

#Write your code below this line 👇
cross = input("you have to cross a road quick!! pick left or right? ")
cross = cross.lower()
if cross == 'right':
    print("Oops you fell in a hole! Game over")
elif cross == 'left':
    river = input("Now there's a river! Swim or Wait? ")
    river = river.lower()
    if river == 'swim':
        print("you got attacked by a trout,Game over")
    elif river == 'wait':
        print("Thank God I didn't swim :)")
        print("Now finally there are three coloured doors!!")
        print("RED , YELLOW and BLUE")
        color = input("which color are you going to pick? ")
        color.lower()
        if color == 'yellow':
            print("You are free now ,you WON!!!")
        elif color == 'red':
            print("sorry, you are burned by fire :(")
        elif color == 'blue':
            print("Oh GOD! you got eaten by Beasts")
        else:
            print("wrong input!! Game Over")
else:
    print("wrong input!! Game Over")
