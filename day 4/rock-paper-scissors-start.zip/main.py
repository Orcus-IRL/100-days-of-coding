rock = '''
    _______
---'   ____)
      (_____)
      (_____)
      (____)
---.__(___)
'''

paper = '''
    _______
---'   ____)____
          ______)
          _______)
         _______)
---.__________)
'''

scissors = '''
    _______
---'   ____)____
          ______)
       __________)
      (____)
---.__(___)
'''

#Write your code below this line 👇
import random

images = [rock, paper, scissors]

choose = int(
    input(
        "What do you choose? Type 0 for Rock, 1 for paper, 2 for scissors:\n"))
if choose == 0 or choose == 1 or choose == 2:
    print(images[choose])
    computer_choose = random.randint(0, 2)
    print("computer choose:", images[computer_choose])
    if choose == computer_choose:
        print("It's a draw!")
    elif (choose == 0
          and computer_choose == 2) or (choose == 1 and computer_choose
                                        == 0) or (choose == 2
                                                  and computer_choose == 1):
        print("You WON!")
    else:
        print("You lose!")
else:
    print("Oops wrong Input\nSo computer won \nType either 0, 1 or 2!!")
